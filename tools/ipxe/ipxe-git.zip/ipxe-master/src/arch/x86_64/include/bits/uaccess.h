#ifndef _BITS_UACCESS_H
#define _BITS_UACCESS_H

/** @file
 *
 * x86_64-specific user access API implementations
 *
 */

#endif /* _BITS_UACCESS_H */
