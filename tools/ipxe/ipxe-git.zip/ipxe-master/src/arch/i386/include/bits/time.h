#ifndef _BITS_TIME_H
#define _BITS_TIME_H

/** @file
 *
 * i386-specific time API implementations
 *
 */

FILE_LICENCE ( GPL2_OR_LATER );

#include <ipxe/rtc_time.h>

#endif /* _BITS_TIME_H */
