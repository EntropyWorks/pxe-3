#ifndef _LINUX_API_PLATFORM_H
#define _LINUX_API_PLATFORM_H

extern int linux_errno;

#endif /* _LINUX_API_PLATFORM_H */
