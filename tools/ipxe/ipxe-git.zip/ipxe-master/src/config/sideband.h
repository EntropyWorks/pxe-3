#ifndef CONFIG_SIDEBAND_H
#define CONFIG_SIDEBAND_H

/** @file
 *
 * Sideband access by platform firmware
 *
 */

FILE_LICENCE ( GPL2_OR_LATER );

//#define	CONFIG_BOFM	/* IBM's BladeCenter Open Fabric Manager */

#include <config/local/sideband.h>

#endif /* CONFIG_SIDEBAND_H */
