Intel(R) Boot Agent image utility for BIOS developers
=====================================================

This archive is for BIOS developers for the purpose of
creating an Intel(R) Boot Agent image for use with a
LAN on Motherboard implementation.

For plug-in NIC's, you should use the utility 
BootUtil.exe. For a copy of the BootUtil utility,
download PREBOOT.EXE from Intel support. BootUtil.exe
is used to update and configure the pre-boot firmware
on NIC's.